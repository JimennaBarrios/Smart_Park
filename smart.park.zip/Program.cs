﻿using System;
using System.ComponentModel.Design;

namespace SmartPark
{
    class Program
    {
        static void Main(string[] args)
        {
            // Configuración de inicio en el sistema
            Console.Title = "SMART PARK - Sistema de Gestión";
            Random generadorAleatorio = new Random();

            // Inicio de un turno
            Console.WriteLine("=================================");
            Console.WriteLine("     BIENVENIDO A SMART PARK     ");
            Console.WriteLine("=================================");

            Console.Write("Nombre del operador en turno: ");
            string operador = Console.ReadLine() ?? "Operador General";
            Console.WriteLine("¿El nombre esta correcto?");
                bool correcto = false;

            Console.ReadLine();
            string codigoTurno = generadorAleatorio.Next(1000, 10000).ToString();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\nSISTEMA INICIADO");
            Console.WriteLine($"Código de Turno Asignado: {codigoTurno}");
            Console.ResetColor();
            Console.WriteLine("---------------------------------\n");

            // variables de control
            int capacidadTotal = 0;
            int espaciosOcupados = 0;
            int totalTicketsCreados = 0;
            int totalTicketsCerrados = 0;
            double ingresosTotales = 0.0;
            int minutosSimulados = 0;

            // Datos del vehículo
            string placaActiva = "";
            string nombreCliente = "";
            int tipoVehiculoActivo = 0;
            bool esVIP = false;
            int minutoIngresoVehiculo = 0;

            // Capacidad del parqueo (mínimo 10)
            while (capacidadTotal < 10)
            {
                Console.Write("Defina la capacidad del parqueo (mínimo 10): ");
                if (!int.TryParse(Console.ReadLine(), out capacidadTotal) || capacidadTotal < 10)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error: Ingrese un número válido >= 10.");
                    Console.ResetColor();
                }
            }

            // Menú principal
            bool salir = false;
            while (!salir)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\n=================================");
                Console.WriteLine($"   SMART PARK | Turno: {codigoTurno}");
                Console.WriteLine("=================================");
                Console.WriteLine("1. Registrar Entrada (Ticket)");
                Console.WriteLine("2. Simular Paso del Tiempo");
                Console.WriteLine("3. Registrar Salida (Cobro)");
                Console.WriteLine("4. Ver Estado General");
                Console.WriteLine("5. Cerrar Turno y Salir");
                Console.WriteLine("=================================");
                Console.ResetColor();
                Console.Write("Seleccione una opción: ");
                string opcion = Console.ReadLine() ?? "";

                Console.Clear();
                switch (opcion)
                {
                    case "1": // Registro de entrada
                        if (placaActiva != "")
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("ALERTA: Ya hay un vehículo en el espacio de prueba.");
                            Console.ResetColor();
                        }
                        else if (espaciosOcupados >= capacidadTotal)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("ERROR: No hay espacios disponibles.");
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.WriteLine("--- NUEVO TICKET ---");
                            Console.Write("Placa (6-8 caracteres): ");
                            placaActiva = Console.ReadLine() ?? "S/P";

                            Console.Write("Tipo (1: Moto, 2: Auto, 3: Pickup): ");
                            int.TryParse(Console.ReadLine(), out tipoVehiculoActivo);

                            Console.Write("Nombre del cliente: ");
                            nombreCliente = Console.ReadLine() ?? "Consumidor Final";

                            Console.Write("¿Es cliente VIP? (S/N): ");
                            esVIP = (Console.ReadLine()?.ToUpper() == "S");

                            minutoIngresoVehiculo = minutosSimulados;
                            espaciosOcupados++;
                            totalTicketsCreados++;

                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("\n¡Vehículo registrado exitosamente!");
                            Console.ResetColor();
                        }
                        break;

                    case "2": // Paso del tiempo
                        Console.Write("¿Cuántos minutos transcurren? (máx 1440): ");
                        if (int.TryParse(Console.ReadLine(), out int mins) && mins > 0 && mins <= 1440)
                        {
                            minutosSimulados += mins;
                            Console.WriteLine($"Reloj actualizado. Tiempo actual: {minutosSimulados} min.");
                        }
                        else
                        {
                            Console.WriteLine("Valor de tiempo no válido.");
                        }
                        break;

                    case "3": // Registro de salida y cobro
                        if (placaActiva == "")
                        {
                            Console.WriteLine("No hay vehículos registrados para cobrar.");
                        }
                        else
                        {
                            int tiempoEstancia = minutosSimulados - minutoIngresoVehiculo;
                            if (tiempoEstancia < 0) tiempoEstancia = 0;

                            // Definición de tarifa por tipo
                            double tarifaBase = (tipoVehiculoActivo == 1) ? 5 : (tipoVehiculoActivo == 2) ? 10 : 15;
                            double montoPagar = 0;

                            if (tiempoEstancia > 15) // 15 minutos son cortesía
                            {
                                // Cobro por hora o fracción
                                int horasACobrar = (int)Math.Ceiling(tiempoEstancia / 60.0);
                                montoPagar = horasACobrar * tarifaBase;

                                // Multa por exceder 6 horas
                                if (tiempoEstancia > 360)
                                {
                                    montoPagar += 25;
                                    Console.WriteLine("(!) Aplicada multa de Q25.00 por estadía prolongada.");
                                }

                                // Descuento VIP
                                if (esVIP)
                                {
                                    montoPagar *= 0.90;
                                    Console.WriteLine("(!) Descuento del 10% aplicado por membresía VIP.");
                                }
                            }
                            Console.WriteLine("------------------------------");
                            Console.WriteLine($"RECIBO DE PAGO - Placa: {placaActiva}");
                            Console.WriteLine($"Tiempo total: {tiempoEstancia} minutos");
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine($"TOTAL A CANCELAR: Q{montoPagar:F2}");
                            Console.ResetColor();
                            Console.WriteLine("------------------------------");

                            ingresosTotales += montoPagar;
                            totalTicketsCerrados++;
                            espaciosOcupados--;
                            placaActiva = ""; // Liberar el espacio
                        }
                        break;

                    case "4": // Estado del sistema
                        Console.WriteLine("ESTADO DEL SISTEMA");
                        Console.WriteLine($"Operador: {operador} | Turno: {codigoTurno}");
                        Console.WriteLine($"Ocupación: {espaciosOcupados} de {capacidadTotal}");
                        Console.WriteLine($"Espacios Libres: {capacidadTotal - espaciosOcupados}");
                        Console.WriteLine($"Recaudación Actual: Q{ingresosTotales:F2}");
                        Console.WriteLine($"Tickets totales: {totalTicketsCreados}");
                        if (placaActiva != "") Console.WriteLine($"Vehículo en uso: {placaActiva}");
                        break;

                    case "5": // Salir y cerrar turno
                        salir = true;
                        Console.Clear();
                        Console.WriteLine("=================================");
                        Console.WriteLine("       CIERRE DE TURNO     ");
                        Console.WriteLine("=================================");
                        Console.WriteLine($"Operador: {operador}");
                        Console.WriteLine($"Código de Turno: {codigoTurno}");
                        Console.WriteLine($"Tickets Cerrados: {totalTicketsCerrados}");
                        Console.WriteLine($"Total Recaudado: Q{ingresosTotales:F2}");
                        Console.WriteLine("=================================");
                        Console.WriteLine("Presione una tecla para salir...");
                        Console.ReadKey();
                        break;

                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }

                if (!salir)
                {
                    Console.WriteLine("\nPresione ENTER para volver al menú...");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
        }
    }
}